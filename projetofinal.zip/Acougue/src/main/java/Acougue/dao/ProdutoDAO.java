package Acougue.dao;


import com.mycompany.acougue.Classes.Produto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ProdutoDAO {

    public static String url = "jdbc:mysql://localhost:3306/supremomeat";
    public static String usuario = "root";
    public static String senha = "";

    public static boolean salvar(Produto p) {
        boolean retorno = false;
        Connection conexao = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            conexao = DriverManager.getConnection(url, usuario, senha);

            PreparedStatement comandoSQL
                    = conexao.prepareStatement("INSERT INTO produto (codigo, nome_produto, quantidade, precocompra, precovenda, fornecedor) VALUES (?,?,?,?,?,?)");

            comandoSQL.setInt(1, p.getCodigo());
            comandoSQL.setString(2, p.getNomeProduto());
            comandoSQL.setInt(3, p.getQuantidade());
            comandoSQL.setDouble(4, p.getPrecoCompra());
            comandoSQL.setDouble(5, p.getPrecoVenda());
            comandoSQL.setString(6, p.getFornecedor());

            int linhasAfetadas = comandoSQL.executeUpdate();

            if (linhasAfetadas > 0) {

                retorno = true;
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return retorno;
    }

    public static ArrayList<Produto> listar() {
        ArrayList<Produto> produtoslist = new ArrayList();
        Connection conexao = null;
        ResultSet rs = null;
        
        try {
            //1)Carregar o Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2) Abrir a conexão
            conexao = DriverManager.getConnection(url, usuario, senha);

            //3) Preparar o comando sql
            PreparedStatement comandoSQL
                    = conexao.prepareStatement(
                            "SELECT * FROM produto");

            //4) Executar o comando SQL
            rs = comandoSQL.executeQuery();

            //Enquanto houver linhas no resultset, adiciono um objeto 
            //na lista de retorno
            while (rs.next()) {
                int id = rs.getInt("id");
                int codigo = rs.getInt("codigo");
                String nome_produto = rs.getString("nome_produto");
                int quantidade = rs.getInt("quantidade");
                double precocompra = rs.getDouble("precocompra");
                double precovenda = rs.getDouble("precovenda");
                String fornecedor = rs.getString("fornecedor");

                Produto item = new Produto(id, codigo, nome_produto, quantidade, precocompra, precovenda, fornecedor);
                produtoslist.add(item);

            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return produtoslist;
    }

    public static boolean excluir(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
