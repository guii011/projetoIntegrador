package Acougue.dao;

import com.mycompany.acougue.Classes.Cliente;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Gui_f
 */
public class ClienteDAO {

    public static String url = "jdbc:mysql://localhost:3306/supremomeat";
    public static String usuario = "root";
    public static String senha = "";

    public static boolean cadastrar(Cliente c) {
        boolean retorno = false;
        Connection conexao = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            conexao = DriverManager.getConnection(url, usuario, senha);

            PreparedStatement comandoSQL
                    = conexao.prepareStatement("INSERT INTO cliente (nome, cpf, telefone, email, sexo, estadoCivil, endereco) VALUES (?,?,?,?,?,?,?)");

            comandoSQL.setString(1, c.getNome());
            comandoSQL.setString(2, c.getCpf());
            comandoSQL.setString(3, c.getTelefone());
            comandoSQL.setString(4, c.getEmail());
            comandoSQL.setString(5, c.getSexo());
            comandoSQL.setString(6, c.getEstadoCivil());
            comandoSQL.setString(7, c.getEndereco());

            int linhasAfetadas = comandoSQL.executeUpdate();

            if (linhasAfetadas > 0) {

                retorno = true;
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return retorno;
    }

    public static ArrayList<Cliente> listar() {
        ArrayList<Cliente> clientsList = new ArrayList<>();
        Connection conexao = null;
        ResultSet rs = null;

        try {
            //1)Carregar o Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2) Abrir a conexão
            conexao = DriverManager.getConnection(url, usuario, senha);

            //3) Preparar o comando sql
            PreparedStatement comandoSQL
                    = conexao.prepareStatement(
                            "SELECT * FROM cliente");

            //4) Executar o comando SQL
            rs = comandoSQL.executeQuery();

            //Enquanto houver linhas no resultset, adiciono um objeto 
            //na lista de retorno
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String cpf = rs.getString("cpf");
                String telefone = rs.getString("telefone");
                String email = rs.getString("email");
                String sexo = rs.getString("sexo");
                String estadoCivil = rs.getString("estadoCivil");
                String endereco = rs.getString("endereco");

                Cliente item = new Cliente(id, nome, cpf, telefone, email, sexo, estadoCivil, endereco);
                clientsList.add(item);

            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return clientsList;
    }

    public static Cliente encontrarClientePorCPF(String cpf) {
        Connection conexao = null;
        ResultSet rs = null;
        Cliente c = null;
        try {

            //1)Carregar o Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2) Abrir a conexão
            conexao = DriverManager.getConnection(url, usuario, senha);

            //3) Preparar o comando sql
            PreparedStatement comandoSQL
                    = conexao.prepareStatement(
                            "SELECT * FROM cliente WHERE cliente.cpf = ?");

            //4) Executar o comando SQL
            comandoSQL.setString(1, cpf);
            rs = comandoSQL.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String telefone = rs.getString("telefone");
                String email = rs.getString("email");
                String sexo = rs.getString("sexo");
                String estadoCivil = rs.getString("estadoCivil");
                String endereco = rs.getString("endereco");

                Cliente item = new Cliente(id, nome, cpf, telefone, email, sexo, estadoCivil, endereco);
                c = item;

            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return c;
    }

    public static boolean atualizar(Cliente c) {
        boolean retorno = false;
        Connection conexao = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            conexao = DriverManager.getConnection(url, usuario, senha);

            PreparedStatement comandoSQL
                    = conexao.prepareStatement("UPDATE cliente SET nome = ?, cpf = ?, telefone = ?, email = ?, sexo = ?, estadoCivil = ?, endereco = ? WHERE id = ?");

            comandoSQL.setString(1, c.getNome());
            comandoSQL.setString(2, c.getCpf());
            comandoSQL.setString(3, c.getTelefone());
            comandoSQL.setString(4, c.getEmail());
            comandoSQL.setString(5, c.getSexo());
            comandoSQL.setString(6, c.getEstadoCivil());
            comandoSQL.setString(7, c.getEndereco());
            System.out.println(c.getIdCliente());
            comandoSQL.setInt(8, c.getIdCliente());

            int linhasAfetadas = comandoSQL.executeUpdate();

            if (linhasAfetadas > 0) {

                retorno = true;
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return retorno;
    }
}
