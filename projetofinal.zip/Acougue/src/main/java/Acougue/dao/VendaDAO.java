/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Acougue.dao;

import com.mycompany.acougue.Classes.Venda;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gui_f
 */
public class VendaDAO {

    public static String url = "jdbc:mysql://localhost:3306/supremomeat";
    public static String usuario = "root";
    public static String senha = "";

    public static int salvar(Venda v) {
        int idvenda = -1;
        Connection conexao = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            conexao = DriverManager.getConnection(url, usuario, senha);

            PreparedStatement comandoSQL
                    = conexao.prepareStatement("INSERT INTO venda (dia, vendedor, totalvenda) VALUES (?,?,?)", PreparedStatement.RETURN_GENERATED_KEYS);

            comandoSQL.setString(1, v.getDia());
            comandoSQL.setString(2, v.getVendedor());
            comandoSQL.setDouble(3, v.getTotalvenda());

            comandoSQL.executeUpdate();
            ResultSet rs = comandoSQL.getGeneratedKeys();

            if (rs.next()) {

                idvenda = rs.getInt(1);
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return idvenda;
    }

    public static ArrayList<Venda> listar() {
        ArrayList<Venda> vendaslist = new ArrayList();
        Connection conexao = null;
        ResultSet rs = null;

        try {
            //1)Carregar o Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2) Abrir a conexão
            conexao = DriverManager.getConnection(url, usuario, senha);

            //3) Preparar o comando sql
            PreparedStatement comandoSQL
                    = conexao.prepareStatement(
                            "SELECT * FROM venda");

            //4) Executar o comando SQL
            rs = comandoSQL.executeQuery();

            //Enquanto houver linhas no resultset, adiciono um objeto 
            //na lista de retorno
            while (rs.next()) {
                String dia = rs.getString("dia");
                String vendedor = rs.getString("vendedor");
                double totalvenda = rs.getDouble("totalvenda");

                Venda item = new Venda(dia, vendedor, totalvenda);
                vendaslist.add(item);

            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return vendaslist;
    }

    public static boolean excluir(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static ArrayList<Venda> listarPorData(String inicialDate, String lastDate) {
        ArrayList<Venda> vendaslist = new ArrayList();
        Connection conexao = null;
        ResultSet rs = null;

        try {
            //1)Carregar o Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2) Abrir a conexão
            conexao = DriverManager.getConnection(url, usuario, senha);

            //3) Preparar o comando sql
            PreparedStatement comandoSQL
                    = conexao.prepareStatement(
                            "SELECT * FROM venda AS v WHERE v.dia >= ? AND v.dia <= ?");

            comandoSQL.setString(1, inicialDate);
            comandoSQL.setString(2, lastDate);
            
            
            //4) Executar o comando SQL
            rs = comandoSQL.executeQuery();

            //Enquanto houver linhas no resultset, adiciono um objeto 
            //na lista de retorno
            while (rs.next()) {
                String dia = rs.getString("dia");
                String vendedor = rs.getString("vendedor");
                double totalvenda = rs.getDouble("totalvenda");

                Venda item = new Venda(dia, vendedor, totalvenda);
                vendaslist.add(item);

            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return vendaslist;
    }

}
