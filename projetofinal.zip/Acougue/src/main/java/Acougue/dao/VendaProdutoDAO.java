package Acougue.dao;

import com.mycompany.acougue.Classes.Venda;
import com.mycompany.acougue.Classes.VendaProdutoData;
import java.awt.List;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VendaProdutoDAO {

    public static String url = "jdbc:mysql://localhost:3306/supremomeat";
    public static String usuario = "root";
    public static String senha = "";

    public static boolean salvar(ArrayList<Integer> idlist) {
        boolean retorno = false;
        Connection conexao = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            conexao = DriverManager.getConnection(url, usuario, senha);

            PreparedStatement comandoSQL
                    = conexao.prepareStatement("INSERT INTO vendaproduto (idproduto, idvenda) VALUES (?,?)");

            comandoSQL.setInt(1, idlist.get(0));
            comandoSQL.setInt(2, idlist.get(1));

            int linhasAfetadas = comandoSQL.executeUpdate();

            if (linhasAfetadas > 0) {

                retorno = true;
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return retorno;
    }

    public static ArrayList<VendaProdutoData> listar(String inicialDate) {
        ArrayList<VendaProdutoData> vendaslist = new ArrayList();
        Connection conexao = null;
        ResultSet rs = null;

        try {
            //1)Carregar o Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2) Abrir a conexão
            conexao = DriverManager.getConnection(url, usuario, senha);

            //3) Preparar o comando sql
            PreparedStatement comandoSQL
                    = conexao.prepareStatement(
                            "SELECT V.idvenda, V.dia, V.vendedor, V.totalvenda,\n"
                            + "p.nome_produto, p.quantidade\n"
                            + "FROM venda AS v \n"
                            + "INNER JOIN vendaproduto AS vp ON v.idvenda = vp.idvenda\n"
                            + "INNER JOIN produto AS p ON vp.idproduto = p.id WHERE v.dia = ?");
            
            comandoSQL.setString(1, inicialDate);
           

            //4) Executar o comando SQL
            rs = comandoSQL.executeQuery();

            //Enquanto houver linhas no resultset, adiciono um objeto 
            //na lista de retorno
            while (rs.next()) {
                Date dia = rs.getDate("dia");
                String vendedor = rs.getString("vendedor");
                double totalvenda = rs.getDouble("totalvenda");
                int idvenda = rs.getInt("idvenda");
                String nome_produto = rs.getString("nome_produto");
                int quantidade = rs.getInt("quantidade");

                VendaProdutoData item = new VendaProdutoData(idvenda, dia, vendedor, totalvenda, nome_produto, quantidade);
                vendaslist.add(item);

            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return vendaslist;
    }
}
