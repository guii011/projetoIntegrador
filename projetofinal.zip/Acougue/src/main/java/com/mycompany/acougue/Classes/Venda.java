package com.mycompany.acougue.Classes;

public class Venda {

    private int idVenda;
    private String dia;
    private String vendedor;
    private double totalvenda;

    public Venda(int idVenda, String dia, String vendedor, double totalVenda) {
        this.idVenda = idVenda;
        this.dia = dia;
        this.vendedor = vendedor;
        this.totalvenda = totalVenda;
    }

    public Venda(String dia, String vendedor, double totalVenda) {
        this.dia = dia;
        this.vendedor = vendedor;
        this.totalvenda = totalVenda;
    }

    public int getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getVendedor() {
        return vendedor;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }

    public double getTotalvenda() {
        return totalvenda;
    }

    public void setTotalvenda(double totalvenda) {
        this.totalvenda = totalvenda;
    }

}
