
package com.mycompany.acougue;

public class Acougue {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
