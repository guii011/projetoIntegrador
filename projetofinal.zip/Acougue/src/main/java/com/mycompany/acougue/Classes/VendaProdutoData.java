
package com.mycompany.acougue.Classes;

import java.sql.Date;

public class VendaProdutoData {
    
    private int idVenda;
    private Date dia;
    private String vendedor;
    private double totalvenda;
    private String nome_produto;
    private int quantidade;

    public VendaProdutoData(int idVenda, Date dia, String vendedor, double totalvenda, String nome_produto, int quantidade) {
        this.idVenda = idVenda;
        this.dia = dia;
        this.vendedor = vendedor;
        this.totalvenda = totalvenda;
        this.nome_produto = nome_produto;
        this.quantidade = quantidade;
    }

    public int getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    public Date getDia() {
        return dia;
    }

    public void setDia(Date dia) {
        this.dia = dia;
    }

    public String getVendedor() {
        return vendedor;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }

    public double getTotalvenda() {
        return totalvenda;
    }

    public void setTotalvenda(double totalvenda) {
        this.totalvenda = totalvenda;
    }

    public String getNome_produto() {
        return nome_produto;
    }

    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public String toString() {
        return "VendaProdutoData{" + "idVenda=" + idVenda + ", dia=" + dia + ", vendedor=" + vendedor + ", totalvenda=" + totalvenda + ", nome_produto=" + nome_produto + ", quantidade=" + quantidade + '}';
    }
    
    
    
}


