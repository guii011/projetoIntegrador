package com.mycompany.acougue.Classes;

public class Produto {

    private int id;
    private int Codigo;
    private String NomeProduto;
    private int Quantidade;
    private double PrecoCompra;
    private double PrecoVenda;
    private String Fornecedor;

    public Produto(int id, int Codigo, String NomeProduto, int Quantidade, double PrecoCompra, double PrecoVenda, String Fornecedor) {
        this.id = id;
        this.Codigo= Codigo;
        this.NomeProduto = NomeProduto;
        this.Quantidade = Quantidade;
        this.PrecoCompra = PrecoCompra;
        this.PrecoVenda = PrecoVenda;
        this.Fornecedor = Fornecedor;
    }

    public Produto(int Codigo, String NomeProduto, int Quantidade, double PrecoCompra, double PrecoVenda, String Fornecedor) {
        this.Codigo = Codigo;
        this.NomeProduto = NomeProduto;
        this.Quantidade = Quantidade;
        this.PrecoCompra = PrecoCompra;
        this.PrecoVenda = PrecoVenda;
        this.Fornecedor = Fornecedor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public String getNomeProduto() {
        return NomeProduto;
    }

    public void setNomeProduto(String NomeProduto) {
        this.NomeProduto = NomeProduto;
    }

    public int getQuantidade() {
        return Quantidade;
    }

    public void setQuantidade(int Quantidade) {
        this.Quantidade = Quantidade;
    }

    public double getPrecoCompra() {
        return PrecoCompra;
    }

    public void setPrecoCompra(double PrecoCompra) {
        this.PrecoCompra = PrecoCompra;
    }

    public double getPrecoVenda() {
        return PrecoVenda;
    }

    public void setPrecoVenda(double PrecoVenda) {
        this.PrecoVenda = PrecoVenda;
    }

    public String getFornecedor() {
        return Fornecedor;
    }

    public void setFornecedor(String Fornecedor) {
        this.Fornecedor = Fornecedor;

    }
}
